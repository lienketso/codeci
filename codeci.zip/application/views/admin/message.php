<div class="alert alert-success">
<button type="button" class="close" data-dismiss="alert">×</button>
<strong>Thông báo : <?php echo $message ?> </strong> 
</div>
