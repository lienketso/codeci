<html>
   <!-- the head -->
   <head>
      <meta http-equiv="Content-Type" content="text/html ;charset=utf-8" />
   </head>
   <body>
   <div id="content" class="span10">
       <h1>Upload file</h1>
       <form method="post" action="" enctype="multipart/form-data">
                <label>Ảnh minh họa:</label>
                <input type="file"  id="image" name="image"><br />
                <input type="submit" class="button" value="Upload" name='submit' />
        </form>
        </div>
   </body>
</html>