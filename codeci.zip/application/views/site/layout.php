<html>
	<head><?php $this->load->view('site/head'); ?></head>
	<body class="cms-index-index index-opt-4">
	<div class="wrapper">
		<header class="site-header header-opt-4">
			<?php $this->load->view('site/header',$this->data); ?>
		</header>

		 <main class="site-main">
		 <?php $this->load->view($temp,$this->data); ?>
		 </main>

 		<footer class="site-footer footer-opt-4">
		<?php $this->load->view('site/footer'); ?>
		</footer>
	</div>
   <!--back-to-top  -->
        <a href="#" class="back-to-top">
            <i aria-hidden="true" class="fa fa-angle-up"></i>
        </a>
    <!-- jQuery -->    
    <script type="text/javascript" src="<?php echo public_url(); ?>site/js/jquery.min.js"></script>
    <!-- Boostrap --> 
    <script type="text/javascript" src="<?php echo public_url(); ?>site/js/bootstrap.js"></script>
    <!-- sticky -->
    <script type="text/javascript" src="<?php echo public_url(); ?>site/js/jquery.sticky.js"></script>
    <!-- OWL CAROUSEL Slider -->    
    <script type="text/javascript" src="<?php echo public_url(); ?>site/js/owl.carousel.js"></script>
    <!-- Countdown -->    
    <script type="text/javascript" src="<?php echo public_url(); ?>site/js/jquery.countdown.min.js"></script>
    <!-- Chosen jquery-->    
    <script type="text/javascript" src="<?php echo public_url(); ?>site/js/chosen.jquery.js"></script>
    <!-- Main -->  
    <script type="text/javascript" src="<?php echo public_url(); ?>site/js/main.js"></script>
    <script>

        (function($) {

            "use strict";

            $(document).ready(function() {

                /*  [ Filter by price ]

                - - - - - - - - - - - - - - - - - - - - */

                $('#slider-range').slider({

                    range: true,

                    min: 0,

                    max: 500,

                    values: [0, 300],

                    slide: function (event, ui) {

                        $('#amount-left').text(ui.values[0] );
                        $('#amount-right').text(ui.values[1] );

                    }

                });

                $('#amount-left').text($('#slider-range').slider('values', 0));

                $('#amount-right').text($('#slider-range').slider('values', 1));
            }); 

        })(jQuery);

    </script>

	</body>
</html>
