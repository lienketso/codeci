<?php
Class News_model extends My_Model{
	var $table = 'news';
}