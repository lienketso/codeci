<?php
function public_url($url=''){
	return base_url('public/'.$url);
}