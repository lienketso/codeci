<?php
Class Cart_model extends MY_Model{
	var $table = 'cart';
}