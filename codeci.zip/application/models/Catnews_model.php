<?php
Class Catnews_model extends MY_Model{
	var $table = 'catnews';
}