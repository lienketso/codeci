<?php
Class Home extends MY_Controller {
	function index(){
		//data từ core->My_controller
		$this->data["temp"] = 'admin/home/index';
		$this->load->view('admin/main',$this->data);
	}
}