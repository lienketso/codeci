<?php
Class Setting_model extends MY_Model{
	var $table = 'setting';
}