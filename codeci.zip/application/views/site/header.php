
            <div class="header-top">
                <div class="container">

                    <ul class="hotline nav-left" >
                        <li class="dropdown switcher  switcher-currency">
                            <a data-toggle="dropdown" role="button" href="#" class="dropdown-toggle switcher-trigger"><span>USD</span> <i aria-hidden="true" class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu switcher-options ">
                                <li class="switcher-option">
                                    <a href="#">
                                        <i class="fa fa-usd" aria-hidden="true"></i>USD
                                    </a>
                                </li>
                                <li class="switcher-option">
                                    <a href="#">
                                        <i class="fa fa-eur" aria-hidden="true"></i>eur
                                    </a>
                                </li>
                                <li class="switcher-option">
                                    <a href="#">
                                        <i class="fa fa-gbp" aria-hidden="true"></i>gbp
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown switcher  switcher-language">
                            <a data-toggle="dropdown" role="button" href="#" class="dropdown-toggle switcher-trigger" aria-expanded="false">
                                <img class="switcher-flag" alt="flag" src="<?php echo public_url(); ?>site/images/flag_english.png">
                                <span>English</span> 
                                <i aria-hidden="true" class="fa fa-angle-down"></i>
                            </a>
                            <ul class="dropdown-menu switcher-options ">
                                <li class="switcher-option">
                                    <a href="#">
                                        <img class="switcher-flag" alt="flag" src="<?php echo public_url(); ?>site/images/flag_english.png">English
                                    </a>
                                </li>
                                <li class="switcher-option">
                                    <a href="#">
                                        <img class="switcher-flag" alt="flag" src="<?php echo public_url(); ?>site/images/flag_french.png">French
                                    </a>
                                </li>
                                <li class="switcher-option">
                                    <a href="#">
                                        <img class="switcher-flag" alt="flag" src="<?php echo public_url(); ?>site/images/flag_germany.png">Germany
                                    </a>
                                </li>
                            </ul>
                        </li>

                    </ul>

                    <ul class="links nav-right">
                        <?php if(isset($user_info)): ?>
                        <li><a href="<?php echo base_url('user/index/'.$user_info->id); ?>">Xin chào ! <?php echo $user_info->name ?></a></li>
                        <li><a href="<?php echo base_url('user/logout'); ?>">Đăng xuất</a></li>
                        <?php else: ?>
                        <li ><a href="<?php echo base_url('user/register'); ?>">Đăng ký</a></li>
                        <li><a href="<?php echo base_url('user/login'); ?>" >Đăng nhập</a></li>
                        <?php endif; ?>
                    </ul>

                </div>
            </div>

            <!-- header-content -->
            <div class="header-content">
                <div class="container">

                    <div class="clearfix">
                        <div class="custom-link">
                        <ul class="link">
                            <li><a href="">Promotion  </a></li>
                            <li><a href="">Guarantee  </a></li>
                            <li><a href="">Payment  </a></li>
                            <li><a href="">Shipping  </a></li>
                            <li><a href="">Return  </a></li>
                            <li><a href="">Call +64 123 456      </a></li>
                        </ul>
                        <div class="text-free"><img src="<?php echo public_url(); ?>site/images/text-free.png" alt="img">Buy 10 Products or 1000 Get Free Shipping</div>
                    </div>

                    </div>

                    <div class="row">

                        <div class="col-md-3 nav-left">
                            <!-- logo -->
                            <strong class="logo">
                                <a href="<?php echo base_url(); ?>"><img src="<?php echo public_url(); ?>site/images/logo.png" alt="logo"></a>
                            </strong><!-- logo -->
                        </div>

                        <div class="col-md-5 col-lg-6 nav-mind">

                            <!-- block search -->
                            <div class="block-search">
                                <div class="block-title">
                                    <span>Search</span>
                                </div>
                                <div class="block-content">
                                   
                                    <div class="form-search">
                                        <form method="get" action="<?php echo base_url('product/search'); ?>">
                                            <div class="box-group">
                                <input type="text" name="key" class="form-control" placeholder="Tìm kiếm sản phẩm">
                                <button class="btn btn-search" type="submit"><span>search</span></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div><!-- block search -->

                        </div>

                        <div class="col-md-4 col-lg-3 nav-right">

                            <!-- block mini cart -->
                            <div class="block-minicart dropdown">
                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                                    <span class="cart-icon"></span>
                                    <span class="counter qty">
                                        <span class="cart-text">Giỏ hàng</span>
                                        <span class="counter-number">( <?php echo $total_items; ?> )</span>
                                        <span class="counter-label"><?php echo $total_items; ?> <span>Sản phẩm</span></span>
                                      
                                    </span>
                                </a>
                                <div class="dropdown-menu">
                                    <form>
                                        <div  class="minicart-content-wrapper" >
                                            
                                            <div class="actions">
                                                <a class="btn btn-viewcart" href="<?php echo base_url('cart'); ?>">
                                                    <span>Vào giỏ hàng</span>
                                                </a>
                                                <button class="btn btn-checkout" type="button" title="Check Out">
                                                    <span>Thanh toán</span>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div><!-- block mini cart -->

                            
                            
                            <!-- link  Login-->
                         
                            <!-- link  Login-->


                        </div>

                    </div>                    

                </div>
            </div><!-- header-content -->

            <div class=" header-nav mid-header">
                <div class="container">
                    <div class="box-header-nav">
                        <!-- menu -->
                        <div class="block-nav-menu">
                            <ul class="ui-menu">
                       <?php foreach($menu_list as $row): ?>
                        <?php if(!empty($row->subs)) : ?>
                                <li class="parent">
                 <a href="<?php echo base_url('product/category/'.$row->category_id); ?>"><?php echo $row->name; ?></a>
                                    <span class="toggle-submenu"></span>
                                    <ul class="submenu">
                                         <?php foreach($row->subs as $sub) : ?>
                                        <li><a href="<?php echo base_url('product/category/'.$sub->category_id); ?>"><?php echo $sub->name; ?></a></li>
                                    <?php endforeach; ?>
                                    </ul>
                                </li>
                                 
                             <?php else: ?>
                                <li><a href="<?php echo base_url('product/category/'.$row->category_id); ?>"><?php echo $row->name; ?></a></li>
                             <?php endif; ?>
                             <?php endforeach; ?>
                            </ul>
                        </div><!-- menu -->


                        <span data-action="toggle-nav" class="nav-toggle-menu"><span>Menu</span><i aria-hidden="true" class="fa fa-bars"></i></span>

                        <div class="block-minicart dropdown ">
                            <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                                <span class="cart-icon"></span>
                            </a>
                            <div class="dropdown-menu">
                                <form>
                                    <div  class="minicart-content-wrapper" >
                                        <div class="subtitle">
                                            You have 6 item(s) in your cart
                                        </div>
                                        <div class="minicart-items-wrapper">
                                            <ol class="minicart-items">
                                                <li class="product-item">
                                                    <a class="product-item-photo" href="#" title="The Name Product">
                                                        <img class="product-image-photo" src="images/minicart.jpg" alt="The Name Product">
                                                    </a>
                                                    <div class="product-item-details">
                                                        <strong class="product-item-name">
                                                            <a href="#">Burberry Pink &amp; black</a>
                                                        </strong>
                                                        <div class="product-item-qty">
                                                            <span class="label">Quantity:</span ><span class="number">6</span>
                                                        </div>
                                                        <div class="product-item-price">
                                                            <span class="price"> $17.96</span>
                                                        </div>
                                                        <div class="product-item-actions">
                                                            <a class="action delete" href="#" title="Remove item">
                                                                <span>Remove</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="product-item">
                                                    <a class="product-item-photo" href="#" title="The Name Product">
                                                        <img class="product-image-photo" src="images/minicart.jpg" alt="The Name Product">
                                                    </a>
                                                    <div class="product-item-details">
                                                        <strong class="product-item-name">
                                                            <a href="#">Burberry Pink &amp; black</a>
                                                        </strong>
                                                        <div class="product-item-qty">
                                                            <span class="label">Quantity:</span ><span class="number">6</span>
                                                        </div>
                                                        <div class="product-item-price">
                                                            <span class="price"> $17.96</span>
                                                        </div>
                                                        <div class="product-item-actions">
                                                            <a class="action delete" href="#" title="Remove item">
                                                                <span>Remove</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                        </div>
                                        <div class="subtotal">
                                            <span class="label">Total</span>
                                            <span class="price">$630</span>
                                        </div>
                                        <div class="actions">
                                            <a class="btn btn-viewcart" href="">
                                                <span>Shopping bag</span>
                                            </a>
                                            <button class="btn btn-checkout" type="button" title="Check Out">
                                                <span>Check out</span>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="block-search">
                            <div class="block-title">
                                <span>Search</span>
                            </div>
                            <div class="block-content">
                                <div class="form-search">
                                    <form>
                                        <div class="box-group">
                                            <input type="text" class="form-control" placeholder="Search here...">
                                            <button class="btn btn-search" type="button"><span>search</span></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <div class="dropdown setting">
                            <a data-toggle="dropdown" role="button" href="#" class="dropdown-toggle "><span>Settings</span> <i aria-hidden="true" class="fa fa-user"></i></a>
                            <div class="dropdown-menu  ">
                                <div class="switcher  switcher-language">
                                    <strong class="title">Select language</strong>
                                    <ul class="switcher-options ">
                                        <li class="switcher-option">
                                            <a href="#">
                                                <img class="switcher-flag" alt="flag" src="images/flag_french.png">
                                            </a>
                                        </li>
                                        <li class="switcher-option">
                                            <a href="#">
                                                <img class="switcher-flag" alt="flag" src="images/flag_germany.png">
                                            </a>
                                        </li>
                                        <li class="switcher-option">
                                            <a href="#">
                                                <img class="switcher-flag" alt="flag" src="images/flag_english.png">
                                            </a>
                                        </li>
                                        <li class="switcher-option switcher-active">
                                            <a href="#">
                                                <img class="switcher-flag" alt="flag" src="images/flag_spain.png">
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="switcher  switcher-currency">
                                    <strong class="title">SELECT CURRENCIES</strong>
                                    <ul class="switcher-options ">
                                        <li class="switcher-option">
                                            <a href="#">
                                                <i class="fa fa-usd" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                        <li class="switcher-option switcher-active">
                                            <a href="#">
                                                <i class="fa fa-eur" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                        <li class="switcher-option">
                                            <a href="#">
                                                <i class="fa fa-gbp" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                       
                                    </ul>
                                </div>
                                <ul class="account">
                                    <li><a href="">Wishlist</a></li>
                                    <li><a href="">My Account</a></li>
                                    <li><a href="">Checkout</a></li>
                                    <li><a href="">Compare</a></li>
                                    <li><a href="">Login/Register</a></li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>

