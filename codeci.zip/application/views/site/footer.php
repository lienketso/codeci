 <!-- FOOTER -->
       

            <div class="container">
                <div class="footer-column">
                
                    <div class="row">
                        <div class="col-md-4 col-lg-4 col-sm-6">
                            <strong class="logo-footer">
                                <a href=""><img src="<?php echo public_url(); ?>site/images/logo-footer.png" alt="logo"></a>
                            </strong>

                            <table class="address">
                                <tr>
                                    <td><b>Address:  </b></td>
                                    <td>Example Street 68, Mahattan,New York, USA</td>
                                </tr>
                                <tr>
                                    <td><b>Phone: </b></td>
                                    <td>+ 65 123 456 789</td>
                                </tr>
                                <tr>
                                    <td><b>Email:</b></td>
                                    <td>Support@ovicsoft.com</td>
                                </tr>
                            </table>

                            <div class="payment">
                                <img src="<?php echo public_url(); ?>site/images/payment1.jpg" alt="payment">
                                <img src="<?php echo public_url(); ?>site/images/payment2.jpg" alt="payment">
                                <img src="<?php echo public_url(); ?>site/images/payment3.jpg" alt="payment">
                                <img src="<?php echo public_url(); ?>site/images/payment4.jpg" alt="payment">
                            </div>
                        </div>
                        <div class="col-md-3 col-lg-2 col-sm-6">
                            <div class="links">
                            <h3 class="title">Customer Service</h3>
                            <ul>
                                <li><a href="">Advanced Search</a></li>
                                <li><a href="">Orders And Returns</a></li>
                                <li><a href="">Contacts US</a></li>
                                <li><a href="">RSS</a></li>
                                <li><a href="">Help & FAQ'S</a></li>
                                <li><a href="">Consultant</a></li>
                                <li><a href="">Store Locations</a></li>
                            </ul>
                            </div>
                        </div>
                        <div class="col-md-2 col-lg-2 col-sm-6">
                            <div class="links">
                            <h3 class="title">Products</h3>
                            <ul>
                                <li><a href="">My Order</a></li>
                                <li><a href="">My Wishlist</a></li>
                                <li><a href="">My Credit Slip</a></li>
                                <li><a href="">My Addresses</a></li>
                                <li><a href="">New In</a></li>
                                <li><a href="">Women</a></li>
                                <li><a href="">Lookbook</a></li>
                            </ul>
                            </div>
                        </div>
                        <div class="col-md-3 col-lg-4 col-sm-6">
                            <div class="block-newletter">
                                <div class="block-title">NEWSLETTER</div>
                                <div class="block-content">
                                    <form>
                                    <div class="input-group">
                                        <input type="text" class="form-control" placeholder="Your Email Address">
                                        <span class="input-group-btn">
                                            <button class="btn btn-subcribe" type="button"><span>Subcribe</span></button>
                                        </span>
                                    </div>
                                </form>
                                </div>
                            </div>
                            <div class="block-social">
                                <div class="block-title">Let’s Socialize </div>
                                <div class="block-content">
                                    <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                    <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                    <a href=""><i class="fa fa-youtube" aria-hidden="true"></i></a>
                                    <a href=""><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                    <a href=""><i class="fa fa-camera" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="footer-tag">
                    <div class="title">Hot tags</div>
                    <ul>
                        <li><a href="">32gb tf cart </a></li>
                        <li><a href="">Android smart</a></li>
                        <li><a href="">Arrow Shirts</a></li>
                        <li><a href="">Best mini usb  flash driver</a></li>
                        <li><a href="">Bluetooth motocycle headset</a></li>
                        <li><a href="">Case iphone reflective </a></li>
                        <li><a href="">micro sd card 8gb</a></li>
                        <li><a href="">Kingston</a></li>
                        <li><a href="">Kingston</a></li>
                        <li><a href="">Led tall light</a></li>
                        <li><a href="">Macbook pro</a></li>
                        <li><a href="">Magentech new themes</a></li>
                        <li><a href="">Mecerdes grille</a></li>
                        <li><a href="">Mini book</a></li>
                        <li><a href="">New product</a></li>
                        <li><a href="">PC senter</a></li>
                        <li><a href="">Point shoot</a></li>
                        <li><a href="">Bamos lcd table</a></li>
                        <li><a href="">Pc black</a></li>
                        <li><a href="">Repacement touch screen</a></li>
                        <li><a href="">Sports</a></li>
                        <li><a href="">Themeforest new magent</a></li>
                        <li><a href="">Tripod camera</a></li>
                    </ul>
                </div>

                <div class="copyright">
                    
                    Copyright © 2016 KoolShop. All Rights Reserved. Designed by KoolShop
                   
                </div>

            </div>

        
     