<?php
Class Category_model extends MY_Model{
	var $table = 'category';
	//var $key = 'category_id';
}